﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim i As Integer
        Dim Numero As Integer
        Dim Resultado As Integer
        Dim Tabla As String = ""

        ' Sirve para asegurar que el numero sea valido y en caso de que no sea valido mandara un msgbox de error.

        If Not Integer.TryParse(TextBox1.Text, Numero) Then
            MessageBox.Show("Por favor, ingrese un número válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        ' Sirve para que se genere la tabla de multiplicar del numero deseado crando un bucle de 10 caundo i sea x numero
        For i = 1 To 10
            Resultado = Numero * i
            Tabla &= Numero & " x " & i & " = " & Resultado & vbCrLf
        Next

        ' sirve para que el msgbox genere la tabla de multiplicar del numero seleccionado 
        MessageBox.Show(Tabla, "Tabla del " & Numero, MessageBoxButtons.OK, MessageBoxIcon.Information)

    End Sub
End Class
